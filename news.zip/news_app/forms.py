from django import forms

# class NewsUpdateForm(forms.ModelForm):
#     class Meta:
#         model = News
#         fields = '__all__'